﻿
namespace BrewersBuddy.Models
{
    public enum ContainerType
    {
        Bottle,
        Keg,
        Barrel,
    }

}