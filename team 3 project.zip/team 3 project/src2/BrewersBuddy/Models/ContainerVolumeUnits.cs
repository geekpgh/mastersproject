﻿
namespace BrewersBuddy.Models
{
    public enum ContainerVolumeUnits
    {
        Milliliter,
        Liter,
        Ounce,
        Gallon
    }

}